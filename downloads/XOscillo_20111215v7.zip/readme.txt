Quick start:

Just for Arduino, compile the pde using the arduino IDE and upload the firmware.

Run the Xoscillo.exe, then go to file and select the platform you want to use.

Thanks

Feedback is welcome, please use the forum http://groups.google.com/group/xoscillo


